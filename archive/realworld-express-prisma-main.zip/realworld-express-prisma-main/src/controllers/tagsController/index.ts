export { default as getTags } from "./getTags";
