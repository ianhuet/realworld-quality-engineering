export interface ValidationError {
  body?: Array<string>;
  query?: Array<string>;
}
